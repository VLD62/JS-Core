function leapYear() {
    // TODO:
}